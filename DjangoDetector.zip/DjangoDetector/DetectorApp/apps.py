from django.apps import AppConfig


class DetectorappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DetectorApp'
